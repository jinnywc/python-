import requests
import aiohttp
import asyncio
import aiofiles
import urllib3

def run(url):
        if len(url) > 6:
                try:
                        url = str(url).strip("\r\n")
                        response = requests.get(url)
                        #print(response.headers)
                        login_result = response.headers
                        result_content = response.content
                        result_code = response.status_code
                        try:
                
                                s_login_result = int(login_result["Content-Length"])
                                if result_content !=result_contenti and result_content !=result_contentj and result_code !=302 and s_login_result != 448 and s_login_result != 8868 and s_login_result !=0 and result_code !=404 and result_code == 200:
                                        print(url + "          存在svn漏洞")
                                        filename_r = "result/" + filen.split(".")[0] + "_r.txt"
                                        svn_url = open(filename_r,'a')
                                        svn_url.writelines(url + "\r\n")
                                        if result_code ==404:
                                                r404.writelines(url + "\r\n")
                        
                        except KeyError:
                                keyerror.writelines(url + "\r\n")
                        except requests.exceptions.MissingSchema:
                                miss.writelines(url + "\r\n")
                        except requests.exceptions.ConnectionError:
                                conn.writelines(url + "\r\n")                        
                        except TypeError:
                                typee.writelines(url + "\r\n")
                        except urllib3.exceptions.ProtocolError:
                                protocol.writelines(url + "\r\n")
                except urllib3.exceptions.MaxRetryError:
                        mxaretryerror.writelines(url + "\r\n")
                except requests.exceptions.ConnectionError:
                        conn.writelines(url + "\r\n")                
                        
                
                        

if __name__ == "__main__":
        urli = "http://wyx.cdnu.edu.cn/.svn/entries"
        responsei = requests.get(urli)
        #print(response.headers)
        #login_resulti = response.headers
        result_contenti = responsei.content  
        #print(result_contenti)
        
        urlj = "http://wyx.cdnu.edu.cn/.svn/entries"
        responsej = requests.get(urlj)
        #print(responsej.headers)
        #login_resulti = response.headers
        result_contentj = responsej.content  
        #print(result_contentj)  
        
        filen = input("请输入url字典:")
        filenames = open(filen) 
        filen1 = "result/" + filen.split(".")[0] + "_KeyError.txt"
        keyerror = open(filen1,'a')
        
        filen2 = "result/" + filen.split(".")[0] + "_MissingSchema.txt"
        miss = open(filen2,'a')
        
        filen3 = "result/" + filen.split(".")[0] + "_ConnectionError.txt"
        conn = open(filen3,'a')  
        
        filen4 = "result/" + filen.split(".")[0] + "_TypeError.txt"
        typee = open(filen4,'a') 
        
        filen5 = "result/" + filen.split(".")[0] + "_404.txt"
        r404 = open(filen5,'a') 
        
        filen6 = "result/" + filen.split(".")[0] + "_ProtocolError.txt"
        protocol = open(filen6,'a') 
        
        filen7 = "result/" + filen.split(".")[0] + "_MaxRetryError.txt"
        mxaretryerror = open(filen7,'a') 
        
        loop = asyncio.get_event_loop()
        tasks = [run(url=url) for url in filenames]
        loop.run_until_complete(asyncio.wait(tasks))
        loop.close()