#import os
f = open("butian/url.txt")
d = open("butian/url1.txt",'a')
c = open("butian/url2.txt",'a')
b = open("butian/url3.txt",'a')
a = open("butian/url4.txt",'a')

e = list(set(f))
print(len(e))
i = 1
for line in e:
    if len(line)>5:
        line = str(line)
        line = line.split()[0]
        line = "http://" + line + "\r\n"
        if i <=30000:         
            d.writelines(line)
            i = i+1
        elif 30000<i and i<=60000:
            c.writelines(line)
            i = i+1
        elif 60000<i and i<=90000:
            b.writelines(line)
            i = i+1
        else:
            a.writelines(line)
            i = i+1
        
f.close()
d.close()

#f = open("admin_urlx.txt")
#a = list(set(f))

#l = open("admin_urlx去重.txt",'a')
#for line in a:
    #l.writelines(line)


#f = open("urlx.txt")
#n = open("admin_urlx.txt",'a')

#for url in f:
    #url = url.strip("\r\n")
    #if len(url)>6:
        #if "" in url:
            #n.writelines(url + "\r\n")
            
            
#f = open("admin_url.txt")
#for url in  f:
    #os.system("python3 AngelSword.py " + url)
    
#f.close()